# Communications verification

CPU/Gloo execution completed on avi-sd-gpu-llm13, with CUDA_VISIBLE_DEVICES empty. Torch 2.6.0 was inherited from the pre-existing environment without modifying it. Notebook execution used the isolated HW2 venv and a kernelspec inside the isolated comms directory.

- RED: the original two-process check failed in ring_reduce_scatter with NotImplementedError on both ranks; see comms-red.log.
- GREEN: unchanged supplied check.py passed at 1, 2, 3, 4 processes and chunk sizes 1, 7, 31; see comms-green.log.
- Additional checks passed at all four world sizes for float32, float64, int64; noncontiguous views; exact input preservation; rank-indexed SUM shard; gathered rank order; empty/wrong-shape/uneven-shard rejection. Final rerun is in comms-notebook-execution.log.
- nbclient executed every notebook code cell. The notebook contains actual success outputs for all four world sizes. Original check source is unchanged, and the notebook implementation exactly matches collectives.py.

The original contract requires equal tensor lengths on all ranks. Cross-rank inconsistent inputs are outside that contract and are not collectively validated. The implementation rejects empty tensors and uneven reduce-scatter lengths. Small tensor correctness was measured, not communication throughput. nbformat normalized missing cell identifiers from the original template; kernel startup emitted its standard local TCP warning.
