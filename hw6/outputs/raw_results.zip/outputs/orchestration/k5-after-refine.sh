set -euo pipefail
cd /home/mekashirskiy/dl-course-hw6-20261117
while kill -0 3989802 2>/dev/null; do sleep 15; done
exec bash /home/mekashirskiy/dl-course-hw5-20261031/run_gpu.sh 0 bash .work/k5-commands.sh
