import csv
import json
import os
import subprocess
from pathlib import Path

from run_experiments import measure, start_server, stop_server


def load_rows():
    with Path('last-analysis.json').open('w') as handle:
        subprocess.run(['.venv/bin/python', 'analyze.py'], stdout=handle, check=True)
    rows = [r for r in csv.DictReader(open('outputs/results.csv')) if r['group'] == 'load' and r['config'] == 'eagle3']
    for r in rows:
        assert all(r[key] == 'True' for key in ('duration_verified', 'rate_verified', 'count_verified', 'bins_verified', 'unique_request_ids', 'unique_session_ids')), r
    return rows


process = start_server('eagle3')
try:
    for _ in range(6):
        rows = load_rows()
        lower = max(int(r['rpm']) for r in rows if r['sla_pass'] == 'True')
        failed = [int(r['rpm']) for r in rows if r['sla_pass'] != 'True' and int(r['rpm']) > lower]
        upper = min(failed) if failed else lower + 240
        print(json.dumps({'lower': lower, 'upper': upper}), flush=True)
        if failed and (upper - lower) / lower <= 0.05:
            break
        rpm = round((lower + upper) / 30) * 15
        measure('load', 'eagle3', rpm)
    else:
        raise RuntimeError('Граница SLA не уточнена за 6 замеров')
    Path('outputs/capacity.json').write_text(json.dumps({'config': 'eagle3', 'pass_rpm': lower, 'fail_rpm': upper, 'relative_gap': (upper - lower) / lower}, indent=2))
finally:
    stop_server(process)

import hashlib

environment = json.loads(Path('outputs/environment.json').read_text())
environment['benchmark_http_connection_limit_env'] = os.environ.get('AIPERF_HTTP_CONNECTION_LIMIT')
Path('outputs/environment.json').write_text(json.dumps(environment, indent=2))
manifest = {}
for model, revision in environment['models'].items():
    snapshot = Path('/home/mekashirskiy/.cache/huggingface/hub') / ('models--' + model.replace('/', '--')) / 'snapshots' / revision
    paths = sorted(p for p in snapshot.rglob('*') if p.is_file())
    assert any(p.suffix in ('.safetensors', '.bin') for p in paths), model
    files = {}
    for path in paths:
        digest = hashlib.sha256()
        with path.open('rb') as handle:
            while block := handle.read(16 * 1024 * 1024):
                digest.update(block)
        files[str(path.relative_to(snapshot))] = {'bytes': path.stat().st_size, 'sha256': digest.hexdigest()}
    manifest[model] = {'revision': revision, 'files': files}
Path('outputs/model_manifest.json').write_text(json.dumps(manifest, indent=2))
print('Model SHA256 manifests saved', flush=True)
