set -euo pipefail
.venv/bin/python run_experiments.py large seq256_chunk2048 eagle3_seq256
.venv/bin/python analyze.py > last-analysis.json
extra="$(.venv/bin/python - <<'PYEXTRA'
import csv
rows=[r for r in csv.DictReader(open('outputs/results.csv')) if r['group']=='large']
plain={int(r['rpm']):float(r['p90_s']) for r in rows if r['config']=='seq256_chunk2048' and r['complete']=='True' and int(r['failed'])==0}
spec={int(r['rpm']):float(r['p90_s']) for r in rows if r['config']=='eagle3_seq256' and r['complete']=='True' and int(r['failed'])==0}
print(int(len(plain)==3 and len(spec)==3 and all(spec[rpm]<=plain[rpm] for rpm in plain)))
PYEXTRA
)"
if [ "$extra" = 1 ]; then
    export RPM=3840
    .venv/bin/python run_experiments.py large seq256_chunk2048 eagle3_seq256
    .venv/bin/python analyze.py > last-analysis.json
fi
