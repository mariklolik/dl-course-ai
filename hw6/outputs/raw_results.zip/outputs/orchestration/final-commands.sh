set -euo pipefail
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export PATH="/home/mekashirskiy/dl-course-hw6-20261117/.benchmark/bin:/home/mekashirskiy/dl-course-hw6-20261117/.venv/bin:$PATH"
export PYTHONPATH=/home/mekashirskiy/dl-course-hw6-20261117
export URL=http://127.0.0.1:8616
export RPM=240,960,1920
bash .work/large-commands.sh
.venv/bin/python .work/refine.py
