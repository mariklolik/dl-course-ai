set -euo pipefail
export RPM=60,240,480,720,960
.venv/bin/python run_experiments.py sweep "$1" "$2"
.venv/bin/python analyze.py > last-analysis.json
export RPM=240,480,720,960
.venv/bin/python run_experiments.py load "$2"
.venv/bin/python analyze.py > last-analysis.json
