set -euo pipefail
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export PATH="/home/mekashirskiy/dl-course-hw6-20261117/.venv/bin:$PATH"
export RPM=240,960
.venv/bin/python run_experiments.py large5 eagle5_seq256
.venv/bin/python analyze.py > last-analysis.json
