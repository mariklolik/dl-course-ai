#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

# Пример: bash load_test.sh 240 results/load-240
rpm="${1:-120}"
url="${URL:-http://127.0.0.1:${PORT:-8616}}"
output="${2:-results/load-${rpm}rpm-$(date +%Y%m%d-%H%M%S)}"
mkdir -p "$(dirname "$output")"
mkdir "$output"

# Очищаем кеш 
trap 'curl -fsS -X POST "$url/reset_prefix_cache" >/dev/null' EXIT
curl -fsS -X POST "$url/reset_prefix_cache" >/dev/null

rps="$(awk -v rpm="$rpm" 'BEGIN { print rpm / 60 }')"

aiperf profile --url "$url" --model Qwen/Qwen3-8B \
  --endpoint-type chat --custom-dataset-type raw_payload \
  --input-file data/requests.jsonl --dataset-sampling-strategy sequential \
  --warmup-request-count 40 --warmup-concurrency 8 \
  --benchmark-duration 300 --benchmark-grace-period inf \
  --request-rate "$rps" --arrival-pattern constant \
  --streaming --request-timeout-seconds 120 \
  --export-outputs-json --output-artifact-dir "$output/profile"
