import hashlib
import json
import math
import re
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parent
output = root / 'outputs'
config = json.loads((root / 'experiments.json').read_text())
manifest = json.loads((root / 'data/manifest.json').read_text())
labels = ['sadness', 'joy', 'love', 'anger', 'fear', 'surprise']
data = {s: [json.loads(x) for x in (root / f'data/{s}.jsonl').read_text().splitlines()] for s in ['train', 'validation', 'test']}
normalized = {s: {' '.join(row['text'].casefold().split()) for row in rows} for s, rows in data.items()}
assert all(not(normalized[a] & normalized[b]) for a, b in [('train','validation'), ('train','test'), ('validation','test')])
assert all(len(normalized[s]) == len(data[s]) for s in data)
assert all(hashlib.sha256((root / f'data/{s}.jsonl').read_bytes()).hexdigest() == manifest['sha256'][s] for s in data)
records = []
main = {}
for name, case in config['experiments'].items():
    path = output / name
    summary = json.loads((path / 'summary.json').read_text())
    assert not summary['smoke']
    assert summary['config'] == config and summary['case'] == case and summary['data_manifest'] == manifest
    training = summary['training']
    if name != 'base':
        assert training['actual_epochs'] == 1.0
        assert training['optimizer_steps'] == math.ceil(len(data['train']) / 32)
        assert training['consumed_examples_inferred_from_epoch'] == len(data['train'])
        assert training['consumed_target_tokens_if_complete_epoch'] == manifest['target_tokens']['train']
        assert training['checkpoint_reloaded_for_evaluation']
        history = json.loads((path / 'training_history.json').read_text())
        assert all(math.isfinite(row['loss']) for row in history if 'loss' in row)
        train_loss = training['train_metrics']['train_loss']
        assert abs(summary['metrics']['validation']['completion_nll'] - train_loss) < 0.5
        expected = 1543714304 if name == 'full' else case['r'] * 28 * (41216 if case['target_modules'] == 'all-linear' else 9728 if len(case['target_modules']) == 4 else 4864)
        assert training['trainable_parameters'] == expected
    for split in ['validation','test']:
        predictions = json.loads((path / f'{split}_predictions.json').read_text())
        assert len(predictions) == len(data[split])
        assert len({p['id'] for p in predictions}) == len(predictions)
        assert [(p['id'], p['text'], p['label']) for p in predictions] == [(p['id'],p['text'],p['label']) for p in data[split]]
        for p in predictions:
            expected = labels.index(p['output'].strip()) if p['output'].strip() in labels else -1
            assert p['predicted_label'] == expected
        accuracy = sum(p['label'] == p['predicted_label'] for p in predictions) / len(predictions)
        f1 = []
        for label in range(6):
            tp = sum(p['label'] == label and p['predicted_label'] == label for p in predictions)
            fp = sum(p['label'] != label and p['predicted_label'] == label for p in predictions)
            fn = sum(p['label'] == label and p['predicted_label'] != label for p in predictions)
            f1.append(2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.0)
        macro_f1 = sum(f1)/6
        metric = summary['metrics'][split]
        assert abs(accuracy - metric['accuracy']) < 1e-12
        assert abs(macro_f1 - metric['macro_f1']) < 1e-12
        assert metric['invalid_outputs'] == sum(p['predicted_label'] == -1 for p in predictions)
        records.append({'case':name,'split':split,'n':len(predictions),'accuracy':accuracy,'macro_f1':macro_f1,'invalid':metric['invalid_outputs']})
    log = (output / f'{name}.log').read_text()
    assert not any(x in log for x in ['Traceback (most recent call last)', 'CUDA out of memory', 'Nonfinite'])
    main[name] = summary
ledger = json.loads((output / 'resource_ledger.json').read_text())
assert all(row['exit_code'] == 0 and not row['budget_exceeded'] for row in ledger)
assert sum(row['gpu_seconds'] for row in ledger) < 7200
assert {row['case'] for row in ledger if not row['smoke']} == set(config['experiments'])
verification = {
    'status':'passed', 'host':'avi-gn-fsk40', 'cpu_tests':4,
    'model_revision':config['model_revision'], 'dataset_revision':config['dataset_revision'],
    'data_manifest':manifest, 'independent_scores':records,
    'checks':{'normalized_split_isolation':True,'full_evaluation_coverage':True,'independent_accuracy_and_macro_f1':True,'strict_output_parser':True,'all_configs_one_epoch_same_data':True,'all_saved_checkpoints_reloaded_before_evaluation':True,'parameter_count_matches_formula':True,'finite_losses':True,'eval_train_nll_gap_under_0_5':True,'all_exit_codes_zero':True},
    'gpu_process_seconds':sum(row['gpu_seconds'] for row in ledger),
    'gpu_process_hours':sum(row['gpu_seconds'] for row in ledger)/3600,
    'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.glob('*.py'))},
    'weight_dtypes':{'full_checkpoint':'BF16','lora_adapter_checkpoint':'F32','lora_frozen_base':'BF16'},
    'warnings':{
        'torch_dtype_deprecation':'Deprecated argument still honored in pinned Transformers4.56.2.',
        'pad_bos_eos_alignment':'PAD is intentionally EOS151645; Trainer aligns model config with tokenizer.',
        'fast_tokenizer_pad':'Performance advice only; token IDs and masks verified.',
        'ignored_temperature_top_p_top_k':'do_sample=False uses greedy decoding; sampling defaults are ignored.',
        'peft_missing_unpinned_base_config':'Offline PEFT save cannot look up main config to test vocabulary resize. Vocabulary was not resized, only projection adapters train, and saved adapters reload over the pinned base.'
    },
    'limitations':['One seed and one epoch, no LR search, confidence intervals not estimated.','Accuracy and macro-F1 are two metrics of the same target task, not separate capability benchmarks.','Baseline failure includes invalid output formatting; report invalid rates.','Full and LoRA use different predeclared learning rates.','Concurrent processes use separate H100 GPUs; time is operational wall time.','Raw labels contain conflicting duplicate texts; heldout partitions take priority.','No human panel: manual qualitative review is the assistant authored analysis.']
}
(output / 'verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
with zipfile.ZipFile(output / 'raw_results.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for name in list(config['experiments']) + ['smoke_full','smoke_lora']:
        for path in sorted((output / name).glob('*.json')):
            archive.write(path,f'{name}/{path.name}')
        log=output / f'{name}.log'
        if log.exists():
            archive.write(log,f'{name}/run.log')
    archive.write(output / 'resource_ledger.json','resource_ledger.json')
    archive.write(root / 'data/manifest.json','data_manifest.json')
    for path in sorted(root.glob('*.py')):
        archive.write(path,f'source/{path.name}')
    archive.write(root / 'experiments.json','experiments.json')
    for path in sorted((root/'notes').glob('*')):
        archive.write(path,f'notes/{path.name}')
print(json.dumps({'status':'passed','models':len(main),'gpu_hours':verification['gpu_process_hours'],'metrics':records},indent=2))
