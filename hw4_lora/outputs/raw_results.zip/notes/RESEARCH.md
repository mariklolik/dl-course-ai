# Primary references

- https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct : required instruction-tuned causal LM, 1.54B parameters, native chat template.
- https://huggingface.co/datasets/dair-ai/emotion : existing English six-class emotion dataset, official split 16000/2000/2000, suitable for inexpensive full FT and controlled ablations.
- https://huggingface.co/docs/transformers/v4.56.2/en/main_classes/trainer : standard Trainer handles training and batching.
- https://huggingface.co/docs/peft/en/package_reference/lora : LoraConfig r, lora_alpha, lora_dropout, target_modules; ordinary scaling alpha/r. r ablation at fixed alpha changes both rank and scaling, explicitly disclose.
- https://github.com/mariklolik/dl-course-ai : HW2/HW3 use concise Russian README, real metrics, code and raw verification artifacts. New folder follows this.

The supplied Stepik page could not be fetched by web tool; the complete user-pasted assignment is the authoritative task text.
