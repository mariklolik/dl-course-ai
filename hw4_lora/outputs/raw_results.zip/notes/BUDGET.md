# Experiment budget
max_paths = 1
max_retries_per_path = 2
compute_cap = 2 GPU-hours total process wall time across all GPUs
scale_ceiling = Qwen/Qwen2.5-1.5B-Instruct
training_token_ceiling = 30000000
configurations = 1 baseline, 1 full FT, 9 LoRA (including reference)
GPU concurrency = at most 3, identical H100 80GB on one node

Stop starting new processes when sum of completed and active GPU process-seconds reaches 7200. A watchdog terminates only this homework's processes at cap. Tests, preparation and downloads do not allocate GPU. No external jobs are interrupted.

spent: 1345.222691 GPU-process seconds; 11 main +2 smoke all passed; zero retries; all processes complete
