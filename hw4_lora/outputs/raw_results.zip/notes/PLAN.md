# HW4 LoRA plan

Goal: reproduce Full FT and LoRA experiments on Qwen2.5-1.5B-Instruct on avi-gn-fsk, deliver hw4_lora in mariklolik/dl-course-ai in the style of HW2/HW3.

Discovery: HW2 already uses Transformers Trainer, BF16, seed control and resource summaries; HW3's completion mask is tool-call-specific. Reuse library APIs and established report/artifact structure, add a small task-specific dataset encoder and strict evaluator. Existing homework files remain unchanged.

Architecture: one pinned dataset and tokenizer, one completion-only encoding, one Trainer path with optional PEFT, one greedy generation evaluator. JSON config drives OFAT LoRA changes. Every model evaluates identical validation/test examples. No selection on test: reference LoRA is fixed before training.

Data: dair-ai/emotion, split configuration, official 16k/2k/2k. Normalize/deduplicate strings, test first then validation then train, audit all removals. Model revision 989aa7980e4cf806f80c7fef2b1adb7bc71aa306, data revision cab853a1dbdf4c42c2b3ef2173804746df8825fe.

Training: one epoch, BF16, SDPA, max_length160, batch16 x accumulation2, seed42, fused AdamW. Full LR2e-5, LoRA LR2e-4, same data order. Ref r16 alpha32 dropout.05 q_proj,v_proj. OFAT r4/r64, alpha8/128, dropout0/.15, target qkvo/all-linear. Do not tune LR or claim either approach globally optimal.

Metrics: accuracy and 6-class macro-F1. Strict label parser invalid outputs count as incorrect. Evaluate every configuration on full cleaned validation/test. Store all predictions, per-class metrics and invalid-output rates. Select 10 test IDs before inspecting outputs for qualitative analysis.

Files: worker owns data.py, train.py, evaluate.py, experiments.json, requirements.txt, test_pipeline.py. Root owns runner, report, plots, verification artifacts and git integration. One implementation path, hyperparameters are configurations rather than separate code.

Verification: CPU tests for encoding/masking, isolation, parsing and OFAT; GPU one-step smoke with forward/backward; full finite-loss training and requested sample consumption; saved checkpoint reload comparison; independent metric recomputation and report readback; preserve logs, configs, revisions, hashes and resource receipts.

Delivery: README.md research report, scripts/config/dependency pins, metrics CSV and raw predictions/logs in hw4_lora/outputs. Keep checkpoints remote (large weights excluded from git). Publish code and reports to requested GitHub repository; no external homework submission.
